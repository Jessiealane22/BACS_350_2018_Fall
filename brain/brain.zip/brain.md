# Brain

Computers remember and Humans decide

This exterior brain is a tool that allows you to be what you are good at while taking care of your business.

* [BACS 350 Projects](http://unco-bacs.org/bacs_350/solution)
* [Notes App](notes.php)
* [Page Log](pagelog.php)
* [Test](test.php)

