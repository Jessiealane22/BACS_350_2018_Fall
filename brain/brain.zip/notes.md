# Notes

Remember things by typing notes to your future self.

* [Brain](index.php)
* [Add Note](notes.php?action=add)
